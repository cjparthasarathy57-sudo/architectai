import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { CloudUpload, File, X, AlertCircle, CheckCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface UploadedFile {
  file: File;
  preview?: string;
  status: 'uploading' | 'success' | 'error';
  progress: number;
  error?: string;
}

interface FileUploadProps {
  onFilesUploaded: (files: UploadedFile[]) => void;
  projectId?: string;
  maxFiles?: number;
  maxSize?: number;
  accept?: Record<string, string[]>;
}

export default function FileUpload({ 
  onFilesUploaded, 
  projectId,
  maxFiles = 5,
  maxSize = 10 * 1024 * 1024, // 10MB
  accept = {
    'application/pdf': ['.pdf'],
    'image/jpeg': ['.jpg', '.jpeg'],
    'image/png': ['.png'],
    'application/dwg': ['.dwg'],
    'application/dxf': ['.dxf']
  }
}: FileUploadProps) {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const newFiles: UploadedFile[] = acceptedFiles.map(file => ({
      file,
      status: 'uploading' as const,
      progress: 0,
      preview: file.type.startsWith('image/') ? URL.createObjectURL(file) : undefined
    }));

    setUploadedFiles(prev => [...prev, ...newFiles]);

    // Upload files if projectId is provided
    if (projectId) {
      await uploadFiles(newFiles);
    }

    onFilesUploaded([...uploadedFiles, ...newFiles]);
  }, [uploadedFiles, onFilesUploaded, projectId]);

  const uploadFiles = async (files: UploadedFile[]) => {
    for (const uploadFile of files) {
      try {
        const formData = new FormData();
        formData.append('files', uploadFile.file);

        // Simulate upload progress
        const updateProgress = (progress: number) => {
          setUploadedFiles(prev => 
            prev.map(f => 
              f.file === uploadFile.file 
                ? { ...f, progress } 
                : f
            )
          );
        };

        // Simulate progress updates
        for (let i = 0; i <= 100; i += 20) {
          updateProgress(i);
          await new Promise(resolve => setTimeout(resolve, 200));
        }

        const response = await fetch(`/api/projects/${projectId}/upload`, {
          method: 'POST',
          body: formData,
        });

        if (!response.ok) {
          throw new Error(`Upload failed: ${response.statusText}`);
        }

        const result = await response.json();

        setUploadedFiles(prev => 
          prev.map(f => 
            f.file === uploadFile.file 
              ? { ...f, status: 'success', progress: 100 } 
              : f
          )
        );

      } catch (error) {
        setUploadedFiles(prev => 
          prev.map(f => 
            f.file === uploadFile.file 
              ? { ...f, status: 'error', error: error.message } 
              : f
          )
        );
      }
    }
  };

  const removeFile = (fileToRemove: UploadedFile) => {
    setUploadedFiles(prev => prev.filter(f => f !== fileToRemove));
    if (fileToRemove.preview) {
      URL.revokeObjectURL(fileToRemove.preview);
    }
  };

  const { getRootProps, getInputProps, isDragActive, fileRejections } = useDropzone({
    onDrop,
    accept,
    maxFiles,
    maxSize,
    multiple: true
  });

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="space-y-4" data-testid="file-upload-container">
      {/* Upload Zone */}
      <Card>
        <CardContent className="p-0">
          <div
            {...getRootProps()}
            className={cn(
              "border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-all duration-300",
              isDragActive 
                ? "border-primary bg-primary/5" 
                : "border-border hover:border-primary hover:bg-primary/5"
            )}
            data-testid="file-drop-zone"
          >
            <input {...getInputProps()} data-testid="file-input" />
            <div className="space-y-4">
              <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto">
                <CloudUpload className="text-primary text-2xl" />
              </div>
              <div>
                <p className="text-lg font-medium">
                  {isDragActive ? "Drop files here" : "Drop your files here or browse"}
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  Supports PDF, DWG, JPG, PNG up to {formatFileSize(maxSize)}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* File Rejections */}
      {fileRejections.length > 0 && (
        <Card className="border-destructive/50 bg-destructive/5">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <AlertCircle className="text-destructive h-5 w-5 mt-0.5" />
              <div>
                <h4 className="font-medium text-destructive mb-2">Upload Errors</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  {fileRejections.map(({ file, errors }) => (
                    <li key={file.name}>
                      <strong>{file.name}:</strong> {errors.map(e => e.message).join(', ')}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Uploaded Files */}
      {uploadedFiles.length > 0 && (
        <div className="space-y-3" data-testid="uploaded-files-list">
          {uploadedFiles.map((uploadFile, index) => (
            <Card key={index} className="border">
              <CardContent className="p-4">
                <div className="flex items-center space-x-4">
                  {/* File Preview/Icon */}
                  <div className="flex-shrink-0">
                    {uploadFile.preview ? (
                      <img 
                        src={uploadFile.preview} 
                        alt="Preview" 
                        className="w-12 h-12 object-cover rounded"
                      />
                    ) : (
                      <div className="w-12 h-12 bg-muted rounded flex items-center justify-center">
                        <File className="h-6 w-6 text-muted-foreground" />
                      </div>
                    )}
                  </div>

                  {/* File Info */}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{uploadFile.file.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatFileSize(uploadFile.file.size)}
                    </p>
                    
                    {/* Progress Bar */}
                    {uploadFile.status === 'uploading' && (
                      <div className="mt-2">
                        <Progress value={uploadFile.progress} className="h-2" />
                        <p className="text-xs text-muted-foreground mt-1">
                          Uploading... {uploadFile.progress}%
                        </p>
                      </div>
                    )}

                    {/* Error Message */}
                    {uploadFile.status === 'error' && (
                      <p className="text-xs text-destructive mt-1">
                        Error: {uploadFile.error}
                      </p>
                    )}
                  </div>

                  {/* Status Icon */}
                  <div className="flex-shrink-0">
                    {uploadFile.status === 'success' && (
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    )}
                    {uploadFile.status === 'error' && (
                      <AlertCircle className="h-5 w-5 text-destructive" />
                    )}
                  </div>

                  {/* Remove Button */}
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => removeFile(uploadFile)}
                    data-testid={`remove-file-${index}`}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
