import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { 
  ZoomIn, 
  ZoomOut, 
  Maximize, 
  Download,
  FileText,
  Image,
  FileDown
} from "lucide-react";
import type { FloorPlanProject } from "@shared/schema";

interface FloorPlanViewerProps {
  project: FloorPlanProject;
  onDownload?: (format: 'dxf' | 'pdf' | 'png') => void;
}

export default function FloorPlanViewer({ project, onDownload }: FloorPlanViewerProps) {
  const [showDimensions, setShowDimensions] = useState(true);
  const [showFurniture, setShowFurniture] = useState(false);
  const [scale, setScale] = useState(1);
  const [panOffset, setPanOffset] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const canvasRef = useRef<HTMLDivElement>(null);

  const floorPlan = project.floorPlanData;
  const plotDimensions = {
    length: project.plotLength,
    width: project.plotWidth
  };

  const handleZoomIn = () => {
    setScale(prev => Math.min(prev * 1.2, 5));
  };

  const handleZoomOut = () => {
    setScale(prev => Math.max(prev / 1.2, 0.2));
  };

  const handleFitToScreen = () => {
    setScale(1);
    setPanOffset({ x: 0, y: 0 });
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - panOffset.x, y: e.clientY - panOffset.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPanOffset({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  if (!floorPlan) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <p className="text-muted-foreground">No floor plan generated yet.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Floor Plan Viewer */}
      <Card className="overflow-hidden">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">Interactive Floor Plan</CardTitle>
            <div className="flex items-center space-x-4">
              {/* Controls */}
              <div className="flex items-center space-x-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleZoomIn}
                  data-testid="button-zoom-in"
                >
                  <ZoomIn className="h-4 w-4" />
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleZoomOut}
                  data-testid="button-zoom-out"
                >
                  <ZoomOut className="h-4 w-4" />
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleFitToScreen}
                  data-testid="button-fit-screen"
                >
                  <Maximize className="h-4 w-4" />
                </Button>
              </div>

              {/* View Options */}
              <div className="flex items-center space-x-4 text-sm">
                <div className="flex items-center space-x-2">
                  <Switch 
                    checked={showDimensions} 
                    onCheckedChange={setShowDimensions}
                    data-testid="toggle-dimensions"
                  />
                  <Label htmlFor="dimensions">Dimensions</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch 
                    checked={showFurniture} 
                    onCheckedChange={setShowFurniture}
                    data-testid="toggle-furniture"
                  />
                  <Label htmlFor="furniture">Furniture</Label>
                </div>
              </div>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-0">
          <div 
            ref={canvasRef}
            className="floor-plan-viewer h-96 bg-muted/30 relative overflow-hidden cursor-grab active:cursor-grabbing"
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            data-testid="floor-plan-canvas"
          >
            <div 
              className="absolute transition-transform duration-200"
              style={{
                transform: `translate(${panOffset.x}px, ${panOffset.y}px) scale(${scale})`,
                transformOrigin: 'center center'
              }}
            >
              <svg 
                width={plotDimensions.length * 10} 
                height={plotDimensions.width * 10}
                viewBox={`0 0 ${plotDimensions.length * 10} ${plotDimensions.width * 10}`}
                className="border border-foreground bg-background"
                style={{ 
                  minWidth: '400px', 
                  minHeight: '300px',
                  margin: '50px'
                }}
              >
                {/* Plot Boundary */}
                <rect
                  x={0}
                  y={0}
                  width={plotDimensions.length * 10}
                  height={plotDimensions.width * 10}
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="3"
                />

                {/* Setback Lines */}
                <rect
                  x={project.setbackWest * 10}
                  y={project.setbackSouth * 10}
                  width={(plotDimensions.length - project.setbackWest - project.setbackEast) * 10}
                  height={(plotDimensions.width - project.setbackSouth - project.setbackNorth) * 10}
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1"
                  strokeDasharray="5,5"
                  opacity="0.5"
                />

                {/* Rooms */}
                {floorPlan.rooms.map((room, index) => (
                  <g key={index}>
                    {/* Room Rectangle */}
                    <rect
                      x={room.x * 10}
                      y={room.y * 10}
                      width={room.width * 10}
                      height={room.height * 10}
                      fill={getRoomColor(room.type)}
                      stroke="currentColor"
                      strokeWidth="1"
                      opacity="0.3"
                    />
                    
                    {/* Room Border */}
                    <rect
                      x={room.x * 10}
                      y={room.y * 10}
                      width={room.width * 10}
                      height={room.height * 10}
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                    />

                    {/* Room Label */}
                    <text
                      x={room.x * 10 + (room.width * 10) / 2}
                      y={room.y * 10 + (room.height * 10) / 2}
                      textAnchor="middle"
                      dominantBaseline="middle"
                      fontSize="12"
                      fontWeight="bold"
                      fill="currentColor"
                    >
                      {room.name.toUpperCase()}
                    </text>

                    {/* Room Dimensions */}
                    {showDimensions && (
                      <text
                        x={room.x * 10 + (room.width * 10) / 2}
                        y={room.y * 10 + (room.height * 10) / 2 + 15}
                        textAnchor="middle"
                        dominantBaseline="middle"
                        fontSize="10"
                        fill="currentColor"
                        opacity="0.7"
                      >
                        {room.width}' × {room.height}'
                      </text>
                    )}
                  </g>
                ))}

                {/* Doors */}
                {floorPlan.doors?.map((door, index) => (
                  <line
                    key={`door-${index}`}
                    x1={door.x * 10}
                    y1={door.y * 10}
                    x2={(door.x + (door.orientation === 'horizontal' ? door.width : 0)) * 10}
                    y2={(door.y + (door.orientation === 'vertical' ? door.width : 0)) * 10}
                    stroke="green"
                    strokeWidth="4"
                    opacity="0.8"
                  />
                ))}

                {/* Windows */}
                {floorPlan.windows?.map((window, index) => (
                  <line
                    key={`window-${index}`}
                    x1={window.x * 10}
                    y1={window.y * 10}
                    x2={(window.x + (window.orientation === 'horizontal' ? window.width : 0)) * 10}
                    y2={(window.y + (window.orientation === 'vertical' ? window.width : 0)) * 10}
                    stroke="blue"
                    strokeWidth="4"
                    opacity="0.8"
                  />
                ))}

                {/* Overall Dimensions */}
                {showDimensions && (
                  <g>
                    <text
                      x={plotDimensions.length * 5}
                      y={-10}
                      textAnchor="middle"
                      fontSize="14"
                      fontWeight="bold"
                      fill="currentColor"
                    >
                      {plotDimensions.length}'-0"
                    </text>
                    <text
                      x={-15}
                      y={plotDimensions.width * 5}
                      textAnchor="middle"
                      fontSize="14"
                      fontWeight="bold"
                      fill="currentColor"
                      transform={`rotate(-90, -15, ${plotDimensions.width * 5})`}
                    >
                      {plotDimensions.width}'-0"
                    </text>
                  </g>
                )}

                {/* Compass */}
                <g transform={`translate(${plotDimensions.length * 10 - 40}, 40)`}>
                  <circle cx="0" cy="0" r="20" fill="background" stroke="currentColor" strokeWidth="2" />
                  <text x="0" y="-25" textAnchor="middle" fontSize="12" fontWeight="bold" fill="red">
                    N
                  </text>
                  <text x="0" y="-10" textAnchor="middle" fontSize="16">
                    ↑
                  </text>
                </g>
              </svg>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Plan Summary & Downloads */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Plan Summary */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Plan Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Plot Size:</span>
              <span className="font-medium" data-testid="text-plot-size">
                {plotDimensions.length}' × {plotDimensions.width}' ({project.plotTotalArea} sq ft)
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Built Area:</span>
              <span className="font-medium" data-testid="text-built-area">
                {floorPlan.buildingArea} sq ft
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Floor Area Ratio:</span>
              <span className="font-medium" data-testid="text-far">
                {floorPlan.far?.toFixed(3) || 'N/A'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Rooms:</span>
              <span className="font-medium" data-testid="text-room-count">
                {floorPlan.rooms.length} rooms
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Bedrooms:</span>
              <span className="font-medium" data-testid="text-bedroom-count">
                {project.bedrooms}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Bathrooms:</span>
              <span className="font-medium" data-testid="text-bathroom-count">
                {project.bathrooms}
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Vastu Compliance */}
        <Card className={floorPlan.vastuCompliance.score >= 80 ? "border-green-200 bg-green-50/50" : "border-yellow-200 bg-yellow-50/50"}>
          <CardHeader>
            <CardTitle className="text-lg flex items-center space-x-2">
              {floorPlan.vastuCompliance.score >= 80 ? (
                <Badge variant="default" className="bg-green-600">Vastu Compliant</Badge>
              ) : (
                <Badge variant="secondary" className="bg-yellow-600 text-white">Partial Compliance</Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Vastu Score:</span>
              <span className="text-lg font-bold" data-testid="text-vastu-score">
                {floorPlan.vastuCompliance.score}/100
              </span>
            </div>
            
            <Separator />
            
            <div className="space-y-2">
              <h4 className="font-medium text-sm">Compliance Items:</h4>
              <ul className="text-sm space-y-1">
                {floorPlan.vastuCompliance.recommendations?.slice(0, 5).map((item, index) => (
                  <li key={index} className="flex items-start space-x-2">
                    <span className="text-green-600 mt-0.5">✓</span>
                    <span className="text-muted-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {floorPlan.vastuCompliance.violations && floorPlan.vastuCompliance.violations.length > 0 && (
              <div className="space-y-2">
                <h4 className="font-medium text-sm text-yellow-700">Recommendations:</h4>
                <ul className="text-sm space-y-1">
                  {floorPlan.vastuCompliance.violations.slice(0, 3).map((violation, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <span className="text-yellow-600 mt-0.5">!</span>
                      <span className="text-muted-foreground">{violation}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Download Options */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Download Files</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button 
              className="w-full" 
              onClick={() => onDownload?.('dxf')}
              data-testid="button-download-dxf"
            >
              <FileDown className="mr-2 h-4 w-4" />
              AutoCAD DXF
            </Button>
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => onDownload?.('pdf')}
              data-testid="button-download-pdf"
            >
              <FileText className="mr-2 h-4 w-4" />
              PDF (High Resolution)
            </Button>
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => onDownload?.('png')}
              data-testid="button-download-png"
            >
              <Image className="mr-2 h-4 w-4" />
              PNG Image
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function getRoomColor(roomType: string): string {
  const colors = {
    bedroom: '#3b82f6', // blue
    kitchen: '#10b981', // green
    bathroom: '#ef4444', // red
    living: '#8b5cf6', // purple
    dining: '#f59e0b', // amber
    pooja: '#06b6d4', // cyan
    study: '#84cc16', // lime
    storage: '#6b7280', // gray
    balcony: '#14b8a6', // teal
    parking: '#64748b', // slate
    entry: '#f97316', // orange
  };
  
  return colors[roomType.toLowerCase()] || '#6b7280';
}
