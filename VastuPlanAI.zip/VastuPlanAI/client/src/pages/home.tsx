import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Navigation from "@/components/navigation";
import { 
  Home as HomeIcon, 
  Upload, 
  Brain, 
  Wind, 
  Ruler, 
  Eye, 
  Download,
  CheckCircle,
  Play,
  Sparkles,
  Users,
  Clock,
  Award
} from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-secondary via-background to-secondary py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                  AI-Powered{" "}
                  <span className="text-primary">Floor Plans</span>{" "}
                  with Vastu Compliance
                </h1>
                <p className="text-xl text-muted-foreground max-w-2xl">
                  Generate professional, construction-ready house floor plans instantly. 
                  Our AI follows Vastu Shastra principles and Indian climate optimization 
                  for perfect architectural designs.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/input">
                  <Button 
                    size="lg" 
                    className="px-8 py-4 text-lg font-medium"
                    data-testid="button-start-designing"
                  >
                    <Sparkles className="mr-2 h-5 w-5" />
                    Start Designing
                  </Button>
                </Link>
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="px-8 py-4 text-lg font-medium"
                  data-testid="button-watch-demo"
                >
                  <Play className="mr-2 h-5 w-5" />
                  Watch Demo
                </Button>
              </div>
              
              <div className="flex items-center space-x-8 pt-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary" data-testid="stat-plans-generated">50K+</div>
                  <div className="text-sm text-muted-foreground">Plans Generated</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary" data-testid="stat-vastu-compliant">98%</div>
                  <div className="text-sm text-muted-foreground">Vastu Compliant</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary" data-testid="stat-ai-processing">24/7</div>
                  <div className="text-sm text-muted-foreground">AI Processing</div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <Card className="shadow-2xl border">
                <CardContent className="p-8">
                  <div className="floor-plan-grid aspect-square rounded-lg relative bg-muted/30">
                    <div className="absolute inset-4 border-2 border-foreground rounded">
                      <div className="grid grid-cols-3 grid-rows-3 h-full gap-2 p-2">
                        <div className="bg-primary/10 rounded flex items-center justify-center text-xs font-medium">
                          Living
                        </div>
                        <div className="bg-accent/10 rounded flex items-center justify-center text-xs font-medium">
                          Kitchen
                        </div>
                        <div className="bg-primary/10 rounded flex items-center justify-center text-xs font-medium">
                          Dining
                        </div>
                        <div className="bg-muted rounded flex items-center justify-center text-xs font-medium">
                          Bedroom
                        </div>
                        <div className="bg-accent/10 rounded flex items-center justify-center text-xs font-medium">
                          Pooja
                        </div>
                        <div className="bg-muted rounded flex items-center justify-center text-xs font-medium">
                          Bedroom
                        </div>
                        <div className="bg-destructive/10 rounded flex items-center justify-center text-xs font-medium">
                          Toilet
                        </div>
                        <div className="bg-primary/10 rounded flex items-center justify-center text-xs font-medium">
                          Study
                        </div>
                        <div className="bg-accent/10 rounded flex items-center justify-center text-xs font-medium">
                          Entry
                        </div>
                      </div>
                      {/* Compass */}
                      <div className="absolute -top-8 -right-8 bg-card border border-border rounded-full w-16 h-16 flex items-center justify-center font-bold text-sm">
                        <div className="text-center">
                          <div className="text-destructive">N</div>
                          <div className="text-xs text-muted-foreground">↑</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 flex justify-between items-center text-sm text-muted-foreground">
                    <span>Generated in 45 seconds</span>
                    <Badge variant="default" className="bg-green-600">
                      <CheckCircle className="mr-1 h-3 w-3" />
                      Vastu Compliant
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Powerful AI Features</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Our advanced AI system combines architectural expertise with Vastu principles to create perfect floor plans
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Upload className="text-primary text-xl" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Multi-Format Upload</h3>
                <p className="text-muted-foreground">
                  Support for PDF, DWG, images with automatic plot boundary detection and dimension extraction.
                </p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                  <HomeIcon className="text-accent text-xl" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Vastu Shastra</h3>
                <p className="text-muted-foreground">
                  Automatic compliance with Vastu principles for room placement, orientation, and energy flow.
                </p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Wind className="text-primary text-xl" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Climate Optimization</h3>
                <p className="text-muted-foreground">
                  Natural ventilation and daylight optimization specifically designed for Indian climate conditions.
                </p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                  <Ruler className="text-accent text-xl" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Precise Dimensions</h3>
                <p className="text-muted-foreground">
                  Accurate measurements, room areas, and construction-ready specifications with proper scaling.
                </p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Eye className="text-primary text-xl" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Interactive Preview</h3>
                <p className="text-muted-foreground">
                  Zoom, pan, and explore your floor plan with toggleable dimensions and room information.
                </p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                  <Download className="text-accent text-xl" />
                </div>
                <h3 className="text-xl font-semibold mb-3">CAD Export</h3>
                <p className="text-muted-foreground">
                  Download in AutoCAD DXF/DWG format with proper layers, plus PDF and PNG options.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Design Your Dream Home?
          </h2>
          <p className="text-xl opacity-90 mb-8">
            Join thousands of architects and homeowners who trust our AI for perfect floor plans
          </p>
          <Link href="/input">
            <Button 
              size="lg" 
              variant="secondary"
              className="px-8 py-4 text-lg font-medium"
              data-testid="button-cta-start-now"
            >
              <Brain className="mr-2 h-5 w-5" />
              Start Now - It's Free
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <HomeIcon className="text-primary text-xl" />
                <span className="text-lg font-bold">FloorPlan AI</span>
              </div>
              <p className="text-muted-foreground">
                AI-powered floor plan generation with Vastu compliance for modern Indian homes.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <div className="space-y-2">
                <a href="#" className="block text-muted-foreground hover:text-primary transition-colors">
                  Features
                </a>
                <a href="#" className="block text-muted-foreground hover:text-primary transition-colors">
                  Pricing
                </a>
                <a href="#" className="block text-muted-foreground hover:text-primary transition-colors">
                  API
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Resources</h4>
              <div className="space-y-2">
                <Link href="/support">
                  <a className="block text-muted-foreground hover:text-primary transition-colors">
                    Vastu Guide
                  </a>
                </Link>
                <a href="#" className="block text-muted-foreground hover:text-primary transition-colors">
                  CAD Tutorial
                </a>
                <a href="#" className="block text-muted-foreground hover:text-primary transition-colors">
                  Blog
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <div className="space-y-2">
                <Link href="/support">
                  <a className="block text-muted-foreground hover:text-primary transition-colors">
                    Help Center
                  </a>
                </Link>
                <a href="#" className="block text-muted-foreground hover:text-primary transition-colors">
                  Contact Us
                </a>
                <a href="#" className="block text-muted-foreground hover:text-primary transition-colors">
                  Status
                </a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-border pt-8 mt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-muted-foreground">
              &copy; 2024 FloorPlan AI. All rights reserved.
            </p>
            <div className="flex items-center space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                Privacy
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                Terms
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                Security
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
