import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import Navigation from "@/components/navigation";
import FileUpload from "@/components/file-upload";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { plotDetailsSchema, houseRequirementsSchema } from "@shared/schema";
import { z } from "zod";
import { Loader2, CheckCircle, ArrowRight, Home as HomeIcon } from "lucide-react";

const formSchema = plotDetailsSchema.merge(houseRequirementsSchema);
type FormValues = z.infer<typeof formSchema>;

export default function InputForm() {
  const [, setLocation] = useLocation();
  const [currentStep, setCurrentStep] = useState(1);
  const [projectId, setProjectId] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      plotLength: 40,
      plotWidth: 30,
      plotShape: "rectangular",
      roadAccess: "north",
      entryDirection: "North-East (Vastu Preferred)",
      setbackNorth: 5,
      setbackSouth: 3,
      setbackEast: 3,
      setbackWest: 3,
      floors: 1,
      bedrooms: 2,
      bathrooms: 1,
      rooms: {
        kitchen: true,
        dining: true,
        living: true,
        pooja: false,
        study: false,
        parking: false,
        balcony: false,
      },
      specialPreferences: "",
      vastuCompliance: true,
    },
  });

  const createProjectMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      const response = await apiRequest("POST", "/api/projects", {
        ...data,
        plotTotalArea: data.plotLength * data.plotWidth,
      });
      return await response.json();
    },
    onSuccess: (project) => {
      setProjectId(project.id);
      toast({
        title: "Project Created",
        description: "Your floor plan project has been created successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create project",
        variant: "destructive",
      });
    },
  });

  const generateFloorPlanMutation = useMutation({
    mutationFn: async (projectId: string) => {
      const response = await apiRequest("POST", `/api/projects/${projectId}/generate`);
      return await response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({
        title: "Floor Plan Generated!",
        description: "Your floor plan has been generated successfully.",
      });
      setLocation(`/results/${data.project.id}`);
    },
    onError: (error) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate floor plan",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: FormValues) => {
    if (currentStep === 1) {
      // Validate plot details and move to next step
      const plotData = {
        plotLength: data.plotLength,
        plotWidth: data.plotWidth,
        plotShape: data.plotShape,
        roadAccess: data.roadAccess,
        entryDirection: data.entryDirection,
        setbackNorth: data.setbackNorth,
        setbackSouth: data.setbackSouth,
        setbackEast: data.setbackEast,
        setbackWest: data.setbackWest,
      };

      try {
        await apiRequest("POST", "/api/validate/plot", plotData);
        setCurrentStep(2);
      } catch (error) {
        toast({
          title: "Validation Error",
          description: "Please check your plot details and try again.",
          variant: "destructive",
        });
      }
    } else if (currentStep === 2) {
      // Create project and move to generation
      await createProjectMutation.mutateAsync(data);
      setCurrentStep(3);
    } else if (currentStep === 3 && projectId) {
      // Generate floor plan
      await generateFloorPlanMutation.mutateAsync(projectId);
    }
  };

  const handleFilesUploaded = (files: any[]) => {
    // Handle uploaded files
    console.log("Files uploaded:", files);
  };

  const totalArea = form.watch("plotLength") * form.watch("plotWidth");

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="py-20 bg-secondary/50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">Design Your Floor Plan</h1>
            <p className="text-xl text-muted-foreground">
              Provide your requirements and let our AI create the perfect layout
            </p>
          </div>
          
          <Card className="shadow-lg">
            {/* Progress Steps */}
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className={`w-8 h-8 ${currentStep >= 1 ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'} rounded-full flex items-center justify-center text-sm font-medium`}>
                    {currentStep > 1 ? <CheckCircle className="h-4 w-4" /> : '1'}
                  </div>
                  <span className={currentStep === 1 ? "font-medium" : "text-muted-foreground"}>
                    Plot Details
                  </span>
                </div>
                <div className="flex-1 h-px bg-border mx-4"></div>
                <div className="flex items-center space-x-2">
                  <div className={`w-8 h-8 ${currentStep >= 2 ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'} rounded-full flex items-center justify-center text-sm font-medium`}>
                    {currentStep > 2 ? <CheckCircle className="h-4 w-4" /> : '2'}
                  </div>
                  <span className={currentStep === 2 ? "font-medium" : "text-muted-foreground"}>
                    Requirements
                  </span>
                </div>
                <div className="flex-1 h-px bg-border mx-4"></div>
                <div className="flex items-center space-x-2">
                  <div className={`w-8 h-8 ${currentStep >= 3 ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'} rounded-full flex items-center justify-center text-sm font-medium`}>
                    3
                  </div>
                  <span className={currentStep === 3 ? "font-medium" : "text-muted-foreground"}>
                    Generate
                  </span>
                </div>
              </div>
            </CardHeader>
            
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                  {/* Step 1: Plot Details */}
                  {currentStep === 1 && (
                    <div className="space-y-8">
                      {/* File Upload Section */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">Upload Plot Details (Optional)</h3>
                        <FileUpload 
                          onFilesUploaded={handleFilesUploaded}
                          projectId={projectId || undefined}
                        />
                      </div>
                      
                      {/* Plot Dimensions */}
                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-6">
                          <h3 className="text-lg font-semibold">Plot Dimensions</h3>
                          
                          <FormField
                            control={form.control}
                            name="plotLength"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Length (feet)</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    placeholder="40" 
                                    {...field} 
                                    onChange={e => field.onChange(Number(e.target.value))}
                                    data-testid="input-plot-length"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="plotWidth"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Width (feet)</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    placeholder="30" 
                                    {...field} 
                                    onChange={e => field.onChange(Number(e.target.value))}
                                    data-testid="input-plot-width"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="bg-muted p-4 rounded-lg">
                            <div className="flex justify-between items-center">
                              <span className="font-medium">Total Area:</span>
                              <Badge variant="outline" data-testid="badge-total-area">
                                {totalArea.toLocaleString()} sq ft
                              </Badge>
                            </div>
                          </div>
                        </div>
                        
                        <div className="space-y-6">
                          <h3 className="text-lg font-semibold">Orientation & Access</h3>
                          
                          <FormField
                            control={form.control}
                            name="roadAccess"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Road Access</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger data-testid="select-road-access">
                                      <SelectValue placeholder="Select road access" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="north">North</SelectItem>
                                    <SelectItem value="south">South</SelectItem>
                                    <SelectItem value="east">East</SelectItem>
                                    <SelectItem value="west">West</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="entryDirection"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Main Entry Direction</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger data-testid="select-entry-direction">
                                      <SelectValue placeholder="Select entry direction" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="North-East (Vastu Preferred)">North-East (Vastu Preferred)</SelectItem>
                                    <SelectItem value="North">North</SelectItem>
                                    <SelectItem value="East">East</SelectItem>
                                    <SelectItem value="South">South</SelectItem>
                                    <SelectItem value="West">West</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="plotShape"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Plot Shape</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger data-testid="select-plot-shape">
                                      <SelectValue placeholder="Select plot shape" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="rectangular">Rectangular</SelectItem>
                                    <SelectItem value="square">Square</SelectItem>
                                    <SelectItem value="irregular">Irregular</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>
                      
                      {/* Setbacks */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">Setbacks (feet)</h3>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <FormField
                            control={form.control}
                            name="setbackNorth"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>North</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    placeholder="5" 
                                    {...field} 
                                    onChange={e => field.onChange(Number(e.target.value))}
                                    data-testid="input-setback-north"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="setbackSouth"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>South</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    placeholder="3" 
                                    {...field} 
                                    onChange={e => field.onChange(Number(e.target.value))}
                                    data-testid="input-setback-south"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="setbackEast"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>East</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    placeholder="3" 
                                    {...field} 
                                    onChange={e => field.onChange(Number(e.target.value))}
                                    data-testid="input-setback-east"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="setbackWest"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>West</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    placeholder="3" 
                                    {...field} 
                                    onChange={e => field.onChange(Number(e.target.value))}
                                    data-testid="input-setback-west"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {/* Step 2: House Requirements */}
                  {currentStep === 2 && (
                    <div className="space-y-8">
                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-6">
                          <h3 className="text-lg font-semibold">Basic Requirements</h3>
                          
                          <FormField
                            control={form.control}
                            name="floors"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Number of Floors</FormLabel>
                                <Select onValueChange={value => field.onChange(Number(value))} value={field.value.toString()}>
                                  <FormControl>
                                    <SelectTrigger data-testid="select-floors">
                                      <SelectValue placeholder="Select floors" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="1">1 (Ground Floor)</SelectItem>
                                    <SelectItem value="2">2 (Ground + First)</SelectItem>
                                    <SelectItem value="3">3 (Ground + Two Floors)</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="bedrooms"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Bedrooms</FormLabel>
                                <Select onValueChange={value => field.onChange(Number(value))} value={field.value.toString()}>
                                  <FormControl>
                                    <SelectTrigger data-testid="select-bedrooms">
                                      <SelectValue placeholder="Select bedrooms" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="1">1</SelectItem>
                                    <SelectItem value="2">2</SelectItem>
                                    <SelectItem value="3">3</SelectItem>
                                    <SelectItem value="4">4</SelectItem>
                                    <SelectItem value="5">5</SelectItem>
                                    <SelectItem value="6">6</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="bathrooms"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Bathrooms</FormLabel>
                                <Select onValueChange={value => field.onChange(Number(value))} value={field.value.toString()}>
                                  <FormControl>
                                    <SelectTrigger data-testid="select-bathrooms">
                                      <SelectValue placeholder="Select bathrooms" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="1">1</SelectItem>
                                    <SelectItem value="2">2</SelectItem>
                                    <SelectItem value="3">3</SelectItem>
                                    <SelectItem value="4">4</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="space-y-4">
                          <h3 className="text-lg font-semibold">Additional Rooms</h3>
                          <div className="space-y-3">
                            {Object.entries({
                              kitchen: "Kitchen",
                              dining: "Dining Room",
                              living: "Living Room",
                              pooja: "Pooja Room",
                              study: "Study Room",
                              parking: "Parking",
                              balcony: "Balcony",
                            }).map(([key, label]) => (
                              <FormField
                                key={key}
                                control={form.control}
                                name={`rooms.${key}` as keyof FormValues}
                                render={({ field }) => (
                                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                    <FormControl>
                                      <Checkbox
                                        checked={field.value}
                                        onCheckedChange={field.onChange}
                                        data-testid={`checkbox-${key}`}
                                      />
                                    </FormControl>
                                    <div className="space-y-1 leading-none">
                                      <FormLabel>{label}</FormLabel>
                                    </div>
                                  </FormItem>
                                )}
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                      
                      {/* Special Preferences */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">Special Preferences</h3>
                        <FormField
                          control={form.control}
                          name="specialPreferences"
                          render={({ field }) => (
                            <FormItem>
                              <FormControl>
                                <Textarea 
                                  placeholder="Any specific requirements, storage needs, or design preferences..." 
                                  className="h-24 resize-none" 
                                  {...field}
                                  data-testid="textarea-special-preferences"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      {/* Vastu Preferences */}
                      <Card className="bg-accent/5 border-accent/20">
                        <CardContent className="p-6">
                          <FormField
                            control={form.control}
                            name="vastuCompliance"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                    data-testid="switch-vastu-compliance"
                                  />
                                </FormControl>
                                <div className="space-y-2">
                                  <FormLabel className="text-accent font-medium">
                                    Enable Vastu Shastra Compliance
                                  </FormLabel>
                                  <FormDescription className="text-sm text-muted-foreground">
                                    Our AI will ensure kitchen in SE, master bedroom in SW, pooja room in NE, 
                                    and proper placement of all rooms according to Vastu principles.
                                  </FormDescription>
                                </div>
                              </FormItem>
                            )}
                          />
                        </CardContent>
                      </Card>
                    </div>
                  )}
                  
                  {/* Step 3: Generate */}
                  {currentStep === 3 && (
                    <div className="space-y-8 text-center">
                      <div className="space-y-4">
                        <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                          {generateFloorPlanMutation.isPending ? (
                            <Loader2 className="text-primary text-3xl animate-spin" />
                          ) : (
                            <HomeIcon className="text-primary text-3xl" />
                          )}
                        </div>
                        
                        <div>
                          <h3 className="text-2xl font-bold mb-2">
                            {generateFloorPlanMutation.isPending 
                              ? "Generating Your Floor Plan..." 
                              : "Ready to Generate"
                            }
                          </h3>
                          <p className="text-muted-foreground">
                            {generateFloorPlanMutation.isPending 
                              ? "Our AI is creating your perfect layout with Vastu compliance..."
                              : "Click the button below to start AI generation process"
                            }
                          </p>
                        </div>
                        
                        {generateFloorPlanMutation.isPending && (
                          <div className="max-w-md mx-auto">
                            <div className="bg-secondary rounded-full h-3 overflow-hidden mb-2">
                              <div className="bg-gradient-to-r from-primary to-accent h-full rounded-full w-3/4 animate-pulse"></div>
                            </div>
                            <p className="text-sm text-muted-foreground">Processing... This usually takes 1-2 minutes</p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                  
                  <div className="flex justify-between pt-6">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
                      disabled={currentStep === 1 || createProjectMutation.isPending || generateFloorPlanMutation.isPending}
                    >
                      Previous
                    </Button>
                    
                    <div className="flex space-x-4">
                      <Button 
                        type="button" 
                        variant="outline"
                        disabled={!projectId}
                        data-testid="button-save-draft"
                      >
                        Save Draft
                      </Button>
                      
                      <Button 
                        type="submit" 
                        disabled={createProjectMutation.isPending || generateFloorPlanMutation.isPending}
                        data-testid="button-continue-generate"
                      >
                        {createProjectMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        {generateFloorPlanMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        
                        {currentStep === 3 
                          ? (generateFloorPlanMutation.isPending ? "Generating..." : "Generate Floor Plan")
                          : currentStep === 2
                          ? (createProjectMutation.isPending ? "Creating..." : "Create Project")
                          : "Continue"
                        }
                        
                        {currentStep < 3 && !createProjectMutation.isPending && <ArrowRight className="ml-2 h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
