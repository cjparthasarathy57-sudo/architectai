import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import Navigation from "@/components/navigation";
import { Brain, CheckCircle, Loader2, AlertCircle } from "lucide-react";
import type { FloorPlanProject } from "@shared/schema";

interface ProcessingProps {
  params: { id: string };
}

export default function Processing({ params }: ProcessingProps) {
  const [, setLocation] = useLocation();
  const [processingSteps, setProcessingSteps] = useState([
    { label: "Plot boundaries analyzed", completed: false },
    { label: "Vastu principles applied", completed: false },
    { label: "Optimizing room layout", completed: false },
    { label: "Adding dimensions & labels", completed: false },
    { label: "Generating CAD files", completed: false },
  ]);

  const { data: project, isLoading, error } = useQuery<FloorPlanProject>({
    queryKey: ["/api/projects", params.id],
    refetchInterval: (data) => {
      // Stop polling when completed or error
      if (data?.status === "completed" || data?.status === "error") {
        return false;
      }
      return 2000; // Poll every 2 seconds
    },
  });

  // Update processing steps based on progress
  useEffect(() => {
    if (project?.processingProgress) {
      const progress = project.processingProgress;
      setProcessingSteps(prev => prev.map((step, index) => ({
        ...step,
        completed: progress > (index + 1) * 20
      })));
    }
  }, [project?.processingProgress]);

  // Redirect when completed
  useEffect(() => {
    if (project?.status === "completed") {
      setTimeout(() => {
        setLocation(`/results/${params.id}`);
      }, 2000);
    }
  }, [project?.status, params.id, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="py-20">
          <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <Card>
              <CardContent className="p-12">
                <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
                <p className="text-muted-foreground">Loading project...</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  if (error || !project) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="py-20">
          <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <Card className="border-destructive/50 bg-destructive/5">
              <CardContent className="p-12">
                <AlertCircle className="h-8 w-8 text-destructive mx-auto mb-4" />
                <h2 className="text-xl font-semibold mb-2">Project Not Found</h2>
                <p className="text-muted-foreground">
                  The project you're looking for doesn't exist or has been removed.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  if (project.status === "error") {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="py-20">
          <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <Card className="border-destructive/50 bg-destructive/5">
              <CardContent className="p-12">
                <AlertCircle className="h-8 w-8 text-destructive mx-auto mb-4" />
                <h2 className="text-xl font-semibold mb-2">Generation Failed</h2>
                <p className="text-muted-foreground mb-4">
                  {project.errorMessage || "An error occurred while generating your floor plan."}
                </p>
                <button
                  onClick={() => setLocation("/input")}
                  className="text-primary hover:underline"
                >
                  Try Again
                </button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  if (project.status === "completed") {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="py-20">
          <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <Card className="border-green-200 bg-green-50/50">
              <CardContent className="p-12">
                <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <h2 className="text-2xl font-bold mb-2">Floor Plan Ready!</h2>
                <p className="text-muted-foreground mb-4">
                  Your floor plan has been generated successfully. Redirecting to results...
                </p>
                <div className="animate-pulse">
                  <div className="h-2 bg-green-200 rounded-full">
                    <div className="h-2 bg-green-600 rounded-full w-full"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  const progress = project.processingProgress || 0;
  const estimatedTimeRemaining = Math.max(0, Math.ceil((100 - progress) / 10)); // Rough estimate

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="py-20">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Card className="shadow-lg">
            <CardContent className="p-12">
              <div className="space-y-8">
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                  <Brain className="text-primary text-3xl" />
                </div>
                
                <div>
                  <h2 className="text-3xl font-bold mb-4" data-testid="heading-ai-designing">
                    AI is Designing Your Floor Plan
                  </h2>
                  <p className="text-muted-foreground">
                    Our advanced algorithms are analyzing your requirements and creating the perfect layout...
                  </p>
                </div>
                
                {/* Progress Bar */}
                <div className="space-y-4">
                  <Progress value={progress} className="h-3" data-testid="progress-generation" />
                  <p className="text-sm text-muted-foreground" data-testid="text-progress-status">
                    Processing... {progress}% complete
                  </p>
                </div>
                
                {/* Progress Steps */}
                <div className="space-y-4 text-left max-w-md mx-auto">
                  {processingSteps.map((step, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${
                        step.completed 
                          ? "bg-accent text-accent-foreground" 
                          : progress > index * 20 
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground"
                      }`}>
                        {step.completed ? (
                          <CheckCircle className="h-3 w-3" />
                        ) : progress > index * 20 ? (
                          <Loader2 className="h-3 w-3 animate-spin" />
                        ) : (
                          index + 1
                        )}
                      </div>
                      <span className={step.completed ? "text-accent" : progress > index * 20 ? "" : "text-muted-foreground"}>
                        {step.label}
                      </span>
                    </div>
                  ))}
                </div>
                
                <div className="text-xs text-muted-foreground" data-testid="text-time-remaining">
                  {estimatedTimeRemaining > 0 
                    ? `Estimated time remaining: ${estimatedTimeRemaining} minute${estimatedTimeRemaining !== 1 ? 's' : ''}`
                    : "Almost done..."
                  }
                </div>

                {/* Project Details */}
                <div className="pt-4 border-t border-border">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Plot Size:</span>
                      <div className="font-medium">
                        {project.plotLength}' × {project.plotWidth}'
                      </div>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Bedrooms:</span>
                      <div className="font-medium">{project.bedrooms}</div>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Vastu:</span>
                      <div>
                        <Badge variant={project.vastuCompliance ? "default" : "secondary"}>
                          {project.vastuCompliance ? "Enabled" : "Optional"}
                        </Badge>
                      </div>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Status:</span>
                      <div>
                        <Badge variant="outline" className="bg-primary/10">
                          {project.status}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
