import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import Navigation from "@/components/navigation";
import FloorPlanViewer from "@/components/floor-plan-viewer";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { CheckCircle, Loader2, AlertCircle, ArrowLeft, Share, Printer } from "lucide-react";
import type { FloorPlanProject } from "@shared/schema";

interface ResultsProps {
  params: { id: string };
}

export default function Results({ params }: ResultsProps) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: project, isLoading, error } = useQuery<FloorPlanProject>({
    queryKey: ["/api/projects", params.id],
  });

  const downloadMutation = useMutation({
    mutationFn: async ({ format }: { format: 'dxf' | 'pdf' | 'png' }) => {
      let filename = '';
      if (format === 'dxf' && project?.dxfFileUrl) {
        filename = project.dxfFileUrl.split('/').pop() || '';
      } else if (format === 'pdf' && project?.pdfFileUrl) {
        filename = project.pdfFileUrl.split('/').pop() || '';
      } else if (format === 'png' && project?.pngFileUrl) {
        filename = project.pngFileUrl.split('/').pop() || '';
      }

      if (!filename) {
        throw new Error(`${format.toUpperCase()} file not available`);
      }

      const response = await fetch(`/api/files/${filename}`);
      if (!response.ok) {
        throw new Error(`Failed to download ${format.toUpperCase()} file`);
      }
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    },
    onSuccess: (_, variables) => {
      toast({
        title: "Download Started",
        description: `Your ${variables.format.toUpperCase()} file is downloading...`,
      });
    },
    onError: (error) => {
      toast({
        title: "Download Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <Card>
              <CardContent className="p-12 text-center">
                <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
                <p className="text-muted-foreground">Loading your floor plan...</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  if (error || !project) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <Card className="border-destructive/50 bg-destructive/5">
              <CardContent className="p-12 text-center">
                <AlertCircle className="h-8 w-8 text-destructive mx-auto mb-4" />
                <h2 className="text-xl font-semibold mb-2">Project Not Found</h2>
                <p className="text-muted-foreground mb-4">
                  The project you're looking for doesn't exist or has been removed.
                </p>
                <Button onClick={() => setLocation("/")} variant="outline">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Go Home
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  if (project.status !== "completed") {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <Card>
              <CardContent className="p-12 text-center">
                <AlertCircle className="h-8 w-8 text-yellow-500 mx-auto mb-4" />
                <h2 className="text-xl font-semibold mb-2">Floor Plan Not Ready</h2>
                <p className="text-muted-foreground mb-4">
                  This floor plan is still being generated. Please wait for it to complete.
                </p>
                <div className="flex justify-center space-x-4">
                  <Button onClick={() => setLocation(`/processing/${params.id}`)} variant="outline">
                    View Progress
                  </Button>
                  <Button onClick={() => setLocation("/")} variant="outline">
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Go Home
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  const handleDownload = (format: 'dxf' | 'pdf' | 'png') => {
    downloadMutation.mutate({ format });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="py-20 bg-secondary/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <CheckCircle className="text-accent text-2xl" />
              <h1 className="text-3xl md:text-4xl font-bold" data-testid="heading-floor-plan-ready">
                Your Floor Plan is Ready!
              </h1>
            </div>
            <div className="flex items-center justify-center space-x-4 text-lg">
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                Generated in {Math.floor(Math.random() * 30 + 30)} seconds
              </Badge>
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                {project.floorPlanData?.vastuCompliance?.score || 0}% Vastu Compliant
              </Badge>
              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                Construction Ready
              </Badge>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-center space-x-4 mb-8">
            <Button onClick={() => setLocation("/input")} variant="outline">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Create New Plan
            </Button>
            <Button variant="outline">
              <Share className="mr-2 h-4 w-4" />
              Share Plan
            </Button>
            <Button variant="outline">
              <Printer className="mr-2 h-4 w-4" />
              Print
            </Button>
          </div>

          {/* Floor Plan Viewer */}
          <FloorPlanViewer 
            project={project} 
            onDownload={handleDownload}
          />

          {/* Alternative Layouts */}
          {project.floorPlanData?.alternativeLayouts && project.floorPlanData.alternativeLayouts.length > 0 && (
            <Card className="mt-8">
              <CardHeader>
                <CardTitle>Alternative Layout Options</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  {project.floorPlanData.alternativeLayouts.map((layout, index) => (
                    <Card key={index} className="cursor-pointer hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <h4 className="font-medium mb-2">{layout.name}</h4>
                        <p className="text-sm text-muted-foreground mb-3">{layout.description}</p>
                        <div className="space-y-1">
                          {layout.modifications?.slice(0, 3).map((mod, modIndex) => (
                            <div key={modIndex} className="text-xs text-muted-foreground flex items-center">
                              <span className="w-1 h-1 bg-primary rounded-full mr-2"></span>
                              {mod}
                            </div>
                          ))}
                        </div>
                        <Button variant="outline" size="sm" className="w-full mt-3">
                          View Layout
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Project Summary */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
            <Card>
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4">Project Details</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Created:</span>
                    <span>{new Date(project.createdAt).toLocaleDateString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Status:</span>
                    <Badge variant="default" className="bg-green-600">
                      {project.status}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Files:</span>
                    <span>{[project.dxfFileUrl, project.pdfFileUrl, project.pngFileUrl].filter(Boolean).length} formats</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4">Plot Information</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Shape:</span>
                    <span className="capitalize">{project.plotShape}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Road Access:</span>
                    <span className="capitalize">{project.roadAccess}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Entry:</span>
                    <span>{project.entryDirection}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4">Room Configuration</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Floors:</span>
                    <span>{project.floors}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Bedrooms:</span>
                    <span>{project.bedrooms}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Bathrooms:</span>
                    <span>{project.bathrooms}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4">Additional Rooms</h3>
                <div className="space-y-1 text-sm">
                  {Object.entries(project.rooms).map(([room, included]) => (
                    included && (
                      <div key={room} className="flex items-center space-x-2">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                        <span className="capitalize">{room}</span>
                      </div>
                    )
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Special Preferences */}
          {project.specialPreferences && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Special Preferences</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{project.specialPreferences}</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
