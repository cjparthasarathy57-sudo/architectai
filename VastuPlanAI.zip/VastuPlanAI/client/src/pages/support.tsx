import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import Navigation from "@/components/navigation";
import { 
  Book, 
  Bolt, 
  Headphones, 
  Download, 
  Video, 
  FileText,
  MapPin,
  Compass,
  Wind,
  Sun,
  Home as HomeIcon,
  ArrowRight,
  CheckCircle,
  AlertCircle,
  Info
} from "lucide-react";

export default function Support() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-secondary via-background to-secondary">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6" data-testid="heading-support-resources">
            Support & Resources
          </h1>
          <p className="text-xl text-muted-foreground mb-8">
            Learn how to use your floor plans and understand Vastu principles
          </p>
        </div>
      </section>

      {/* Quick Help Cards */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Book className="text-primary text-xl" />
                </div>
                <h3 className="text-lg font-semibold mb-3">Vastu Guide</h3>
                <p className="text-muted-foreground mb-4">
                  Complete guide to Vastu Shastra principles and room placement rules.
                </p>
                <Button variant="ghost" className="text-primary hover:text-primary p-0">
                  Read Guide <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                  <Bolt className="text-accent text-xl" />
                </div>
                <h3 className="text-lg font-semibold mb-3">Using CAD Files</h3>
                <p className="text-muted-foreground mb-4">
                  How to open, edit, and work with AutoCAD DXF files for construction.
                </p>
                <Button variant="ghost" className="text-primary hover:text-primary p-0">
                  Learn More <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Headphones className="text-primary text-xl" />
                </div>
                <h3 className="text-lg font-semibold mb-3">24/7 Support</h3>
                <p className="text-muted-foreground mb-4">
                  Get help with your floor plans, technical issues, or design questions.
                </p>
                <Button variant="ghost" className="text-primary hover:text-primary p-0">
                  Contact Support <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <Tabs defaultValue="vastu" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="vastu" data-testid="tab-vastu">Vastu Guide</TabsTrigger>
              <TabsTrigger value="cad" data-testid="tab-cad">CAD Files</TabsTrigger>
              <TabsTrigger value="tutorials" data-testid="tab-tutorials">Tutorials</TabsTrigger>
              <TabsTrigger value="faq" data-testid="tab-faq">FAQ</TabsTrigger>
            </TabsList>
            
            {/* Vastu Guide */}
            <TabsContent value="vastu" className="mt-8">
              <div className="grid lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Compass className="h-6 w-6 text-primary" />
                        <span>Vastu Shastra Fundamentals</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-muted-foreground">
                        Vastu Shastra is an ancient Indian science of architecture that creates harmony 
                        between human dwellings and natural forces. Our AI follows these time-tested 
                        principles to create balanced and prosperous living spaces.
                      </p>
                      
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="p-4 bg-primary/5 rounded-lg">
                          <h4 className="font-semibold mb-2">Five Elements</h4>
                          <ul className="text-sm space-y-1 text-muted-foreground">
                            <li>• Earth (Prithvi) - Southwest</li>
                            <li>• Water (Jal) - Northeast</li>
                            <li>• Fire (Agni) - Southeast</li>
                            <li>• Air (Vayu) - Northwest</li>
                            <li>• Space (Akash) - Center</li>
                          </ul>
                        </div>
                        
                        <div className="p-4 bg-accent/5 rounded-lg">
                          <h4 className="font-semibold mb-2">Directional Energy</h4>
                          <ul className="text-sm space-y-1 text-muted-foreground">
                            <li>• North - Wealth & Prosperity</li>
                            <li>• East - Health & Family</li>
                            <li>• South - Fame & Recognition</li>
                            <li>• West - Children & Creativity</li>
                          </ul>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <MapPin className="h-6 w-6 text-accent" />
                        <span>Room Placement Guidelines</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Accordion type="single" collapsible className="w-full">
                        <AccordionItem value="kitchen">
                          <AccordionTrigger>Kitchen Placement</AccordionTrigger>
                          <AccordionContent>
                            <div className="space-y-3">
                              <Badge className="bg-green-100 text-green-800 border-green-200">
                                Ideal: Southeast
                              </Badge>
                              <p className="text-sm text-muted-foreground">
                                The kitchen should be in the Southeast direction, governed by the fire element. 
                                This placement enhances health, prosperity, and positive energy in cooking.
                              </p>
                              <ul className="text-sm space-y-1 text-muted-foreground">
                                <li>• Cook facing East or North</li>
                                <li>• Sink in Northeast corner</li>
                                <li>• Gas stove in Southeast</li>
                                <li>• Avoid kitchen in Northeast</li>
                              </ul>
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                        
                        <AccordionItem value="bedroom">
                          <AccordionTrigger>Master Bedroom</AccordionTrigger>
                          <AccordionContent>
                            <div className="space-y-3">
                              <Badge className="bg-blue-100 text-blue-800 border-blue-200">
                                Ideal: Southwest
                              </Badge>
                              <p className="text-sm text-muted-foreground">
                                The master bedroom in Southwest ensures stability, good health, and harmonious 
                                relationships for the head of the family.
                              </p>
                              <ul className="text-sm space-y-1 text-muted-foreground">
                                <li>• Sleep with head towards South or East</li>
                                <li>• Heavy furniture in Southwest</li>
                                <li>• Wardrobe in South or West wall</li>
                                <li>• Avoid mirrors facing the bed</li>
                              </ul>
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                        
                        <AccordionItem value="pooja">
                          <AccordionTrigger>Pooja Room</AccordionTrigger>
                          <AccordionContent>
                            <div className="space-y-3">
                              <Badge className="bg-purple-100 text-purple-800 border-purple-200">
                                Ideal: Northeast
                              </Badge>
                              <p className="text-sm text-muted-foreground">
                                The prayer room in Northeast harnesses divine energy and brings peace, 
                                prosperity, and spiritual growth to the family.
                              </p>
                              <ul className="text-sm space-y-1 text-muted-foreground">
                                <li>• Face East or North while praying</li>
                                <li>• Use light colors like white or yellow</li>
                                <li>• Keep the space clean and clutter-free</li>
                                <li>• Natural light is preferred</li>
                              </ul>
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                        
                        <AccordionItem value="bathroom">
                          <AccordionTrigger>Bathroom & Toilets</AccordionTrigger>
                          <AccordionContent>
                            <div className="space-y-3">
                              <Badge className="bg-orange-100 text-orange-800 border-orange-200">
                                Ideal: Northwest or Southeast
                              </Badge>
                              <p className="text-sm text-muted-foreground">
                                Proper bathroom placement ensures health and prevents negative energy 
                                accumulation in the house.
                              </p>
                              <ul className="text-sm space-y-1 text-muted-foreground">
                                <li>• Never in Northeast or Southwest</li>
                                <li>• Toilet seat facing North or South</li>
                                <li>• Good ventilation is essential</li>
                                <li>• Keep doors closed when not in use</li>
                              </ul>
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      </Accordion>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Vastu Compass */}
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Vastu Compass</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="relative w-64 h-64 mx-auto">
                        <div className="absolute inset-0 rounded-full border-4 border-border">
                          {/* Compass directions */}
                          <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 text-sm font-bold text-red-600">
                            N
                          </div>
                          <div className="absolute -right-4 top-1/2 transform -translate-y-1/2 text-sm font-bold">
                            E
                          </div>
                          <div className="absolute -bottom-4 left-1/2 transform -translate-x-1/2 text-sm font-bold">
                            S
                          </div>
                          <div className="absolute -left-4 top-1/2 transform -translate-y-1/2 text-sm font-bold">
                            W
                          </div>
                          
                          {/* Quadrants */}
                          <div className="absolute top-2 right-2 text-xs p-2 bg-blue-100 rounded text-blue-800">
                            NE<br/>Pooja
                          </div>
                          <div className="absolute bottom-2 right-2 text-xs p-2 bg-red-100 rounded text-red-800">
                            SE<br/>Kitchen
                          </div>
                          <div className="absolute bottom-2 left-2 text-xs p-2 bg-green-100 rounded text-green-800">
                            SW<br/>Master
                          </div>
                          <div className="absolute top-2 left-2 text-xs p-2 bg-yellow-100 rounded text-yellow-800">
                            NW<br/>Guest
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Wind className="h-5 w-5 text-blue-500" />
                        <span>Climate Benefits</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <Sun className="h-4 w-4 text-yellow-500" />
                        <span className="text-sm">Natural light optimization</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Wind className="h-4 w-4 text-blue-500" />
                        <span className="text-sm">Cross ventilation</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-sm">Energy efficiency</span>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
            
            {/* CAD Files */}
            <TabsContent value="cad" className="mt-8">
              <div className="grid lg:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Working with DXF Files</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-muted-foreground">
                        DXF (Drawing Exchange Format) files can be opened in most CAD software 
                        and are perfect for professional architectural work and construction.
                      </p>
                      
                      <div className="space-y-3">
                        <h4 className="font-semibold">Compatible Software:</h4>
                        <div className="grid grid-cols-2 gap-2">
                          <div className="p-3 bg-muted rounded-lg text-sm">AutoCAD</div>
                          <div className="p-3 bg-muted rounded-lg text-sm">SketchUp</div>
                          <div className="p-3 bg-muted rounded-lg text-sm">FreeCAD</div>
                          <div className="p-3 bg-muted rounded-lg text-sm">LibreCAD</div>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <h4 className="font-semibold">File Layers:</h4>
                        <ul className="text-sm space-y-1 text-muted-foreground">
                          <li>• WALLS - Main structure</li>
                          <li>• DOORS - Door openings</li>
                          <li>• WINDOWS - Window positions</li>
                          <li>• TEXT - Room labels</li>
                          <li>• DIMENSIONS - Measurements</li>
                        </ul>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Editing Guidelines</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-3">
                        <div className="flex items-start space-x-3">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                          <div>
                            <h5 className="font-medium">Maintain Scale</h5>
                            <p className="text-sm text-muted-foreground">
                              Keep original proportions when making modifications
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex items-start space-x-3">
                          <Info className="h-5 w-5 text-blue-500 mt-0.5" />
                          <div>
                            <h5 className="font-medium">Layer Management</h5>
                            <p className="text-sm text-muted-foreground">
                              Use separate layers for different elements
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex items-start space-x-3">
                          <AlertCircle className="h-5 w-5 text-yellow-500 mt-0.5" />
                          <div>
                            <h5 className="font-medium">Structural Changes</h5>
                            <p className="text-sm text-muted-foreground">
                              Consult a structural engineer for major modifications
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>File Formats Explained</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-4">
                        <div className="p-4 border rounded-lg">
                          <div className="flex items-center space-x-2 mb-2">
                            <FileText className="h-5 w-5 text-blue-500" />
                            <h5 className="font-semibold">DXF Format</h5>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            Vector-based format perfect for CAD software. Maintains precision 
                            and allows full editing capabilities.
                          </p>
                          <Badge variant="outline" className="mt-2">Professional Use</Badge>
                        </div>
                        
                        <div className="p-4 border rounded-lg">
                          <div className="flex items-center space-x-2 mb-2">
                            <FileText className="h-5 w-5 text-red-500" />
                            <h5 className="font-semibold">PDF Format</h5>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            High-resolution format ideal for printing, presentations, 
                            and sharing with contractors.
                          </p>
                          <Badge variant="outline" className="mt-2">Sharing & Printing</Badge>
                        </div>
                        
                        <div className="p-4 border rounded-lg">
                          <div className="flex items-center space-x-2 mb-2">
                            <FileText className="h-5 w-5 text-green-500" />
                            <h5 className="font-semibold">PNG Format</h5>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            Image format perfect for web use, presentations, 
                            and quick reference viewing.
                          </p>
                          <Badge variant="outline" className="mt-2">Quick Preview</Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Download Tips</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2 text-sm">
                        <li className="flex items-center space-x-2">
                          <Download className="h-4 w-4 text-primary" />
                          <span>Download all formats for different purposes</span>
                        </li>
                        <li className="flex items-center space-x-2">
                          <Download className="h-4 w-4 text-primary" />
                          <span>Keep original files as backup</span>
                        </li>
                        <li className="flex items-center space-x-2">
                          <Download className="h-4 w-4 text-primary" />
                          <span>Share PDF with contractors and authorities</span>
                        </li>
                        <li className="flex items-center space-x-2">
                          <Download className="h-4 w-4 text-primary" />
                          <span>Use DXF for detailed architectural work</span>
                        </li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
            
            {/* Tutorials */}
            <TabsContent value="tutorials" className="mt-8">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <Video className="h-8 w-8 text-primary mb-4" />
                    <h3 className="font-semibold mb-2">Getting Started</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Learn how to upload plot details and set your requirements
                    </p>
                    <Badge variant="outline">5 min</Badge>
                  </CardContent>
                </Card>
                
                <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <Video className="h-8 w-8 text-primary mb-4" />
                    <h3 className="font-semibold mb-2">Understanding Results</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      How to read and interpret your generated floor plan
                    </p>
                    <Badge variant="outline">8 min</Badge>
                  </CardContent>
                </Card>
                
                <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <Video className="h-8 w-8 text-primary mb-4" />
                    <h3 className="font-semibold mb-2">Vastu Compliance</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Understanding Vastu principles in your floor plan
                    </p>
                    <Badge variant="outline">12 min</Badge>
                  </CardContent>
                </Card>
                
                <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <Video className="h-8 w-8 text-primary mb-4" />
                    <h3 className="font-semibold mb-2">Working with CAD</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Opening and editing DXF files in AutoCAD
                    </p>
                    <Badge variant="outline">15 min</Badge>
                  </CardContent>
                </Card>
                
                <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <Video className="h-8 w-8 text-primary mb-4" />
                    <h3 className="font-semibold mb-2">Construction Ready</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Preparing your floor plan for construction
                    </p>
                    <Badge variant="outline">10 min</Badge>
                  </CardContent>
                </Card>
                
                <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <Video className="h-8 w-8 text-primary mb-4" />
                    <h3 className="font-semibold mb-2">Advanced Features</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Tips and tricks for better floor plans
                    </p>
                    <Badge variant="outline">18 min</Badge>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            {/* FAQ */}
            <TabsContent value="faq" className="mt-8">
              <div className="max-w-4xl mx-auto">
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="faq-1">
                    <AccordionTrigger>How accurate are the AI-generated floor plans?</AccordionTrigger>
                    <AccordionContent>
                      Our AI generates highly accurate floor plans based on architectural standards and Vastu principles. 
                      All dimensions, room sizes, and proportions follow industry standards. However, we recommend 
                      having a licensed architect review the plans before construction.
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="faq-2">
                    <AccordionTrigger>Can I modify the generated floor plan?</AccordionTrigger>
                    <AccordionContent>
                      Yes! The DXF files can be opened and edited in any CAD software like AutoCAD, SketchUp, or FreeCAD. 
                      You can modify room sizes, add or remove walls, and adjust the layout according to your needs. 
                      Just ensure you maintain structural integrity and local building codes.
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="faq-3">
                    <AccordionTrigger>Are the floor plans Vastu compliant?</AccordionTrigger>
                    <AccordionContent>
                      When Vastu compliance is enabled, our AI ensures that rooms are placed according to traditional 
                      Vastu Shastra principles. Kitchen in Southeast, master bedroom in Southwest, pooja room in Northeast, 
                      and proper orientation for all spaces. The compliance score shows how well your plan follows these principles.
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="faq-4">
                    <AccordionTrigger>What file formats do you provide?</AccordionTrigger>
                    <AccordionContent>
                      We provide three formats: DXF (for CAD software editing), PDF (for printing and sharing), 
                      and PNG (for quick viewing). Each format serves different purposes - DXF for professional 
                      architectural work, PDF for presentations and approvals, PNG for web and quick reference.
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="faq-5">
                    <AccordionTrigger>How long does it take to generate a floor plan?</AccordionTrigger>
                    <AccordionContent>
                      Floor plan generation typically takes 1-3 minutes depending on complexity. The AI analyzes 
                      your plot details, applies Vastu principles, optimizes room layout, and generates all file 
                      formats. You'll see real-time progress updates during the generation process.
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="faq-6">
                    <AccordionTrigger>Can I upload my existing plot sketch or survey?</AccordionTrigger>
                    <AccordionContent>
                      Yes! You can upload images, PDFs, or DWG files of your plot. Our AI can analyze uploaded 
                      files to extract plot boundaries, dimensions, and features. This helps create more accurate 
                      floor plans tailored to your specific plot characteristics.
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="faq-7">
                    <AccordionTrigger>Do you provide alternative layout options?</AccordionTrigger>
                    <AccordionContent>
                      Yes! Along with the main floor plan, our AI can generate alternative layout options. 
                      These might include different room arrangements, open-plan alternatives, or variations 
                      that optimize for specific needs like more storage or better ventilation.
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="faq-8">
                    <AccordionTrigger>Is the service suitable for commercial buildings?</AccordionTrigger>
                    <AccordionContent>
                      Currently, our AI is optimized for residential floor plans following Vastu principles. 
                      For commercial buildings, we recommend consulting with a commercial architect as they 
                      have different requirements for safety, accessibility, and functionality.
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold mb-4">Still Need Help?</h2>
          <p className="text-xl opacity-90 mb-8">
            Our support team is here to help you with any questions or technical issues
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="secondary" size="lg" data-testid="button-contact-support">
              <Headphones className="mr-2 h-5 w-5" />
              Contact Support
            </Button>
            <Button variant="outline" size="lg" className="bg-transparent border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary">
              <Video className="mr-2 h-5 w-5" />
              Schedule Demo
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
