import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { storage } from "./storage";
import { ensureUploadDirectory, processUploadedFile, validateFileUpload, getFileBuffer } from "./services/fileProcessor";
import { generateFloorPlan, analyzeUploadedPlot } from "./services/openai";
import { generateDXFFile, generatePDFFromFloorPlan, generatePNGFromFloorPlan } from "./services/dxfGenerator";
import { plotDetailsSchema, houseRequirementsSchema, insertFloorPlanProjectSchema } from "@shared/schema";
import { z } from "zod";

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Ensure upload directory exists
  await ensureUploadDirectory();

  // Get all floor plan projects
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.listFloorPlanProjects();
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch projects", error: error.message });
    }
  });

  // Get specific floor plan project
  app.get("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.getFloorPlanProject(req.params.id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch project", error: error.message });
    }
  });

  // Create new floor plan project
  app.post("/api/projects", async (req, res) => {
    try {
      const validatedData = insertFloorPlanProjectSchema.parse(req.body);
      const project = await storage.createFloorPlanProject(validatedData);
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create project", error: error.message });
    }
  });

  // Update floor plan project
  app.patch("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.updateFloorPlanProject(req.params.id, req.body);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to update project", error: error.message });
    }
  });

  // Upload files for project
  app.post("/api/projects/:id/upload", upload.array("files", 5), async (req, res) => {
    try {
      const project = await storage.getFloorPlanProject(req.params.id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      const files = req.files as Express.Multer.File[];
      if (!files || files.length === 0) {
        return res.status(400).json({ message: "No files uploaded" });
      }

      const processedFiles = [];
      const analysisResults = [];

      for (const file of files) {
        validateFileUpload(file);
        const processedFile = await processUploadedFile(file);
        processedFiles.push({
          filename: processedFile.filename,
          originalName: processedFile.originalName,
          mimeType: processedFile.mimeType,
          size: processedFile.size,
          uploadedAt: new Date().toISOString()
        });

        // Analyze images with AI
        if (processedFile.base64) {
          try {
            const analysis = await analyzeUploadedPlot(processedFile.base64);
            analysisResults.push({
              filename: processedFile.filename,
              analysis
            });
          } catch (analysisError) {
            console.warn(`Failed to analyze ${processedFile.filename}:`, analysisError.message);
          }
        }
      }

      // Update project with uploaded files
      const updatedProject = await storage.updateFloorPlanProject(req.params.id, {
        uploadedFiles: [...(project.uploadedFiles || []), ...processedFiles]
      });

      res.json({
        project: updatedProject,
        analysisResults
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to upload files", error: error.message });
    }
  });

  // Generate floor plan using AI
  app.post("/api/projects/:id/generate", async (req, res) => {
    try {
      const project = await storage.getFloorPlanProject(req.params.id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      // Update status to processing
      await storage.updateFloorPlanProject(req.params.id, {
        status: "processing",
        processingProgress: 10
      });

      // Prepare request for AI
      const generationRequest = {
        plotLength: project.plotLength,
        plotWidth: project.plotWidth,
        plotShape: project.plotShape,
        roadAccess: project.roadAccess,
        entryDirection: project.entryDirection,
        setbacks: {
          north: project.setbackNorth,
          south: project.setbackSouth,
          east: project.setbackEast,
          west: project.setbackWest
        },
        floors: project.floors,
        bedrooms: project.bedrooms,
        bathrooms: project.bathrooms,
        rooms: project.rooms,
        specialPreferences: project.specialPreferences,
        vastuCompliance: project.vastuCompliance
      };

      // Update progress
      await storage.updateFloorPlanProject(req.params.id, {
        processingProgress: 30
      });

      // Generate floor plan with AI
      const floorPlan = await generateFloorPlan(generationRequest);

      // Update progress
      await storage.updateFloorPlanProject(req.params.id, {
        processingProgress: 60
      });

      // Generate DXF file
      const dxfResult = await generateDXFFile(
        floorPlan,
        { length: project.plotLength, width: project.plotWidth },
        {
          title: `Floor Plan - ${project.id}`,
          scale: 1,
          units: 'feet',
          includeRoomLabels: true,
          includeDimensions: true,
          includeVastuInfo: true
        }
      );

      // Update progress
      await storage.updateFloorPlanProject(req.params.id, {
        processingProgress: 80
      });

      // Generate PDF and PNG files
      const pdfResult = await generatePDFFromFloorPlan(
        floorPlan,
        { length: project.plotLength, width: project.plotWidth }
      );

      const pngResult = await generatePNGFromFloorPlan(
        floorPlan,
        { length: project.plotLength, width: project.plotWidth }
      );

      // Update project with results
      const updatedProject = await storage.updateFloorPlanProject(req.params.id, {
        status: "completed",
        processingProgress: 100,
        floorPlanData: floorPlan,
        dxfFileUrl: `/api/files/${dxfResult.filename}`,
        pdfFileUrl: `/api/files/${pdfResult.filename}`,
        pngFileUrl: `/api/files/${pngResult.filename}`
      });

      res.json({
        project: updatedProject,
        floorPlan,
        files: {
          dxf: dxfResult.filename,
          pdf: pdfResult.filename,
          png: pngResult.filename
        }
      });
    } catch (error) {
      // Update project with error
      await storage.updateFloorPlanProject(req.params.id, {
        status: "error",
        errorMessage: error.message
      });

      res.status(500).json({ 
        message: "Failed to generate floor plan", 
        error: error.message 
      });
    }
  });

  // Get project processing status
  app.get("/api/projects/:id/status", async (req, res) => {
    try {
      const project = await storage.getFloorPlanProject(req.params.id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      res.json({
        status: project.status,
        progress: project.processingProgress,
        errorMessage: project.errorMessage
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get status", error: error.message });
    }
  });

  // Download generated files
  app.get("/api/files/:filename", async (req, res) => {
    try {
      const { filename } = req.params;
      const fileBuffer = await getFileBuffer(filename);
      
      // Set appropriate content type
      let contentType = 'application/octet-stream';
      if (filename.endsWith('.dxf')) contentType = 'application/dxf';
      else if (filename.endsWith('.pdf')) contentType = 'application/pdf';
      else if (filename.endsWith('.png')) contentType = 'image/png';

      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.send(fileBuffer);
    } catch (error) {
      res.status(404).json({ message: "File not found", error: error.message });
    }
  });

  // Validate plot details
  app.post("/api/validate/plot", async (req, res) => {
    try {
      const validatedData = plotDetailsSchema.parse(req.body);
      res.json({ valid: true, data: validatedData });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          valid: false, 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Validation failed", error: error.message });
    }
  });

  // Validate house requirements
  app.post("/api/validate/requirements", async (req, res) => {
    try {
      const validatedData = houseRequirementsSchema.parse(req.body);
      res.json({ valid: true, data: validatedData });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          valid: false, 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Validation failed", error: error.message });
    }
  });

  // Delete project
  app.delete("/api/projects/:id", async (req, res) => {
    try {
      const success = await storage.deleteFloorPlanProject(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json({ message: "Project deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete project", error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
