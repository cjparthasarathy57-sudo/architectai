import fs from 'fs/promises';
import path from 'path';
import { randomUUID } from 'crypto';

export interface ProcessedFile {
  filename: string;
  originalName: string;
  mimeType: string;
  size: number;
  path: string;
  base64?: string;
}

const UPLOAD_DIR = path.join(process.cwd(), 'uploads');
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
const ALLOWED_MIME_TYPES = [
  'application/pdf',
  'image/jpeg',
  'image/jpg',
  'image/png',
  'application/dwg',
  'application/dxf',
  'image/vnd.dwg',
];

export async function ensureUploadDirectory(): Promise<void> {
  try {
    await fs.mkdir(UPLOAD_DIR, { recursive: true });
  } catch (error) {
    console.error('Failed to create upload directory:', error);
  }
}

export async function processUploadedFile(
  file: Express.Multer.File
): Promise<ProcessedFile> {
  if (!ALLOWED_MIME_TYPES.includes(file.mimetype)) {
    throw new Error(`Unsupported file type: ${file.mimetype}. Allowed types: PDF, DWG, JPG, PNG`);
  }

  if (file.size > MAX_FILE_SIZE) {
    throw new Error(`File too large: ${Math.round(file.size / 1024 / 1024)}MB. Maximum size: 10MB`);
  }

  const filename = `${randomUUID()}-${Date.now()}${path.extname(file.originalname)}`;
  const filePath = path.join(UPLOAD_DIR, filename);

  await fs.writeFile(filePath, file.buffer);

  const processedFile: ProcessedFile = {
    filename,
    originalName: file.originalname,
    mimeType: file.mimetype,
    size: file.size,
    path: filePath,
  };

  // Convert images to base64 for AI analysis
  if (file.mimetype.startsWith('image/')) {
    processedFile.base64 = file.buffer.toString('base64');
  }

  return processedFile;
}

export async function deleteFile(filename: string): Promise<boolean> {
  try {
    const filePath = path.join(UPLOAD_DIR, filename);
    await fs.unlink(filePath);
    return true;
  } catch (error) {
    console.error('Failed to delete file:', error);
    return false;
  }
}

export async function getFileBuffer(filename: string): Promise<Buffer> {
  const filePath = path.join(UPLOAD_DIR, filename);
  return await fs.readFile(filePath);
}

export function validateFileUpload(file: Express.Multer.File): void {
  if (!file) {
    throw new Error('No file uploaded');
  }

  if (!ALLOWED_MIME_TYPES.includes(file.mimetype)) {
    throw new Error(`Invalid file type: ${file.mimetype}`);
  }

  if (file.size > MAX_FILE_SIZE) {
    throw new Error('File size exceeds 10MB limit');
  }
}
