import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_KEY || "default_key"
});

export interface FloorPlanGenerationRequest {
  plotLength: number;
  plotWidth: number;
  plotShape: string;
  roadAccess: string;
  entryDirection: string;
  setbacks: {
    north: number;
    south: number;
    east: number;
    west: number;
  };
  floors: number;
  bedrooms: number;
  bathrooms: number;
  rooms: {
    kitchen: boolean;
    dining: boolean;
    living: boolean;
    pooja: boolean;
    study: boolean;
    parking: boolean;
    balcony: boolean;
  };
  specialPreferences?: string;
  vastuCompliance: boolean;
}

export interface FloorPlanResponse {
  rooms: Array<{
    name: string;
    type: string;
    x: number;
    y: number;
    width: number;
    height: number;
    area: number;
    vastuZone?: string;
  }>;
  doors: Array<{
    x: number;
    y: number;
    width: number;
    orientation: string;
  }>;
  windows: Array<{
    x: number;
    y: number;
    width: number;
    orientation: string;
  }>;
  vastuCompliance: {
    score: number;
    violations: string[];
    recommendations: string[];
  };
  buildingArea: number;
  far: number;
  alternativeLayouts: Array<{
    name: string;
    description: string;
    modifications: string[];
  }>;
}

export async function generateFloorPlan(request: FloorPlanGenerationRequest): Promise<FloorPlanResponse> {
  const systemPrompt = `You are an expert architectural AI that generates precise, professional floor plans following Vastu Shastra principles and Indian climate optimization.

Your task is to create a detailed floor plan based on the user's requirements. Consider:

1. Vastu Shastra Guidelines:
   - Kitchen in South-East (fire element)
   - Master bedroom in South-West (earth element)
   - Pooja room in North-East (water element)
   - Toilets in North-West or South-East
   - Main entrance from North or East (preferred: North-East)
   - Living room in North or East
   - Study room in North-East or East
   - Staircase in South or West

2. Indian Climate Optimization:
   - Cross-ventilation for natural cooling
   - Windows on North and East for morning light
   - Minimize West-facing openings
   - Courtyards or open spaces for air circulation
   - Proper orientation for monsoon protection

3. Architectural Standards:
   - Minimum room sizes (bedroom: 10'x10', kitchen: 8'x10', etc.)
   - Proper circulation paths (3-4 feet corridors)
   - Door and window sizes (doors: 3'x7', windows: 4'x4')
   - Wall thickness: 9 inches for exterior, 4.5 inches for interior

4. Building Regulations:
   - Respect setback requirements
   - Calculate Floor Area Ratio (FAR)
   - Ensure proper room adjacencies
   - Privacy hierarchy (public to private zones)

Generate a floor plan with exact coordinates, dimensions, and comprehensive Vastu analysis. Respond in JSON format only.`;

  const userPrompt = `Generate a floor plan with these requirements:

Plot Details:
- Size: ${request.plotLength}' x ${request.plotWidth}' (${request.plotLength * request.plotWidth} sq ft)
- Shape: ${request.plotShape}
- Road access: ${request.roadAccess}
- Entry direction: ${request.entryDirection}
- Setbacks: North ${request.setbacks.north}', South ${request.setbacks.south}', East ${request.setbacks.east}', West ${request.setbacks.west}'

House Requirements:
- Floors: ${request.floors}
- Bedrooms: ${request.bedrooms}
- Bathrooms: ${request.bathrooms}
- Additional rooms: ${Object.entries(request.rooms).filter(([_, include]) => include).map(([room, _]) => room).join(', ')}
- Vastu compliance: ${request.vastuCompliance ? 'Required' : 'Optional'}
${request.specialPreferences ? `- Special preferences: ${request.specialPreferences}` : ''}

Provide:
1. Exact room layouts with coordinates (x, y from plot origin)
2. Room dimensions and areas
3. Door and window positions
4. Vastu compliance analysis with score (0-100)
5. Building area and FAR calculation
6. 3 alternative layout options

Use coordinate system where (0,0) is the bottom-left corner of the plot.`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    // Validate and ensure all required fields are present
    if (!result.rooms || !Array.isArray(result.rooms)) {
      throw new Error("Invalid floor plan response: missing rooms data");
    }

    return {
      rooms: result.rooms || [],
      doors: result.doors || [],
      windows: result.windows || [],
      vastuCompliance: result.vastuCompliance || { score: 0, violations: [], recommendations: [] },
      buildingArea: result.buildingArea || 0,
      far: result.far || 0,
      alternativeLayouts: result.alternativeLayouts || []
    };

  } catch (error) {
    console.error("OpenAI API Error:", error);
    throw new Error(`Failed to generate floor plan: ${error.message}`);
  }
}

export async function analyzeUploadedPlot(base64Image: string): Promise<{
  detectedDimensions?: { length: number; width: number };
  plotShape: string;
  boundaries: Array<{ x: number; y: number }>;
  suggestions: string[];
}> {
  const prompt = `Analyze this plot image/sketch and extract:
1. Plot dimensions if visible (length x width in feet)
2. Plot shape (rectangular, square, irregular)
3. Boundary coordinates if detectable
4. Any visible features (roads, existing structures, utilities)
5. Recommendations for optimal building placement

Respond in JSON format with detectedDimensions, plotShape, boundaries array, and suggestions array.`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: prompt },
            {
              type: "image_url",
              image_url: { url: `data:image/jpeg;base64,${base64Image}` }
            }
          ]
        }
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || '{}');
  } catch (error) {
    console.error("Plot analysis error:", error);
    throw new Error(`Failed to analyze plot: ${error.message}`);
  }
}
