import { type FloorPlanProject, type InsertFloorPlanProject, type UpdateFloorPlanProject } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Floor Plan Projects
  getFloorPlanProject(id: string): Promise<FloorPlanProject | undefined>;
  createFloorPlanProject(project: InsertFloorPlanProject): Promise<FloorPlanProject>;
  updateFloorPlanProject(id: string, updates: UpdateFloorPlanProject): Promise<FloorPlanProject | undefined>;
  deleteFloorPlanProject(id: string): Promise<boolean>;
  listFloorPlanProjects(userId?: string): Promise<FloorPlanProject[]>;
}

export class MemStorage implements IStorage {
  private floorPlanProjects: Map<string, FloorPlanProject>;

  constructor() {
    this.floorPlanProjects = new Map();
  }

  async getFloorPlanProject(id: string): Promise<FloorPlanProject | undefined> {
    return this.floorPlanProjects.get(id);
  }

  async createFloorPlanProject(insertProject: InsertFloorPlanProject): Promise<FloorPlanProject> {
    const id = randomUUID();
    const now = new Date();
    
    const project: FloorPlanProject = {
      ...insertProject,
      id,
      plotTotalArea: insertProject.plotLength * insertProject.plotWidth,
      createdAt: now,
      updatedAt: now,
    };
    
    this.floorPlanProjects.set(id, project);
    return project;
  }

  async updateFloorPlanProject(id: string, updates: UpdateFloorPlanProject): Promise<FloorPlanProject | undefined> {
    const existing = this.floorPlanProjects.get(id);
    if (!existing) return undefined;

    const updated: FloorPlanProject = {
      ...existing,
      ...updates,
      updatedAt: new Date(),
    };

    // Recalculate total area if dimensions changed
    if (updates.plotLength || updates.plotWidth) {
      updated.plotTotalArea = updated.plotLength * updated.plotWidth;
    }

    this.floorPlanProjects.set(id, updated);
    return updated;
  }

  async deleteFloorPlanProject(id: string): Promise<boolean> {
    return this.floorPlanProjects.delete(id);
  }

  async listFloorPlanProjects(userId?: string): Promise<FloorPlanProject[]> {
    const projects = Array.from(this.floorPlanProjects.values());
    if (userId) {
      return projects.filter(p => p.userId === userId);
    }
    return projects;
  }
}

export const storage = new MemStorage();
