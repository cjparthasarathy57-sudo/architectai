import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const floorPlanProjects = pgTable("floor_plan_projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id"),
  
  // Plot details
  plotLength: integer("plot_length").notNull(),
  plotWidth: integer("plot_width").notNull(),
  plotTotalArea: integer("plot_total_area").notNull(),
  plotShape: text("plot_shape").notNull(), // rectangular, square, irregular
  roadAccess: text("road_access").notNull(), // north, south, east, west
  entryDirection: text("entry_direction").notNull(),
  
  // Setbacks
  setbackNorth: integer("setback_north").notNull().default(0),
  setbackSouth: integer("setback_south").notNull().default(0),
  setbackEast: integer("setback_east").notNull().default(0),
  setbackWest: integer("setback_west").notNull().default(0),
  
  // House requirements
  floors: integer("floors").notNull().default(1),
  bedrooms: integer("bedrooms").notNull().default(2),
  bathrooms: integer("bathrooms").notNull().default(1),
  
  // Additional rooms (stored as JSON for flexibility)
  rooms: json("rooms").$type<{
    kitchen: boolean;
    dining: boolean;
    living: boolean;
    pooja: boolean;
    study: boolean;
    parking: boolean;
    balcony: boolean;
  }>().notNull().default({
    kitchen: true,
    dining: true,
    living: true,
    pooja: false,
    study: false,
    parking: false,
    balcony: false
  }),
  
  // Special preferences
  specialPreferences: text("special_preferences"),
  vastuCompliance: boolean("vastu_compliance").notNull().default(true),
  
  // Generated floor plan data
  floorPlanData: json("floor_plan_data").$type<{
    rooms: Array<{
      name: string;
      type: string;
      x: number;
      y: number;
      width: number;
      height: number;
      area: number;
    }>;
    doors: Array<{
      x: number;
      y: number;
      width: number;
      orientation: string;
    }>;
    windows: Array<{
      x: number;
      y: number;
      width: number;
      orientation: string;
    }>;
    vastuCompliance: {
      score: number;
      violations: string[];
      recommendations: string[];
    };
    buildingArea: number;
    far: number;
  }>(),
  
  // File attachments
  uploadedFiles: json("uploaded_files").$type<Array<{
    filename: string;
    originalName: string;
    mimeType: string;
    size: number;
    uploadedAt: string;
  }>>(),
  
  // Processing status
  status: text("status").notNull().default("draft"), // draft, processing, completed, error
  processingProgress: integer("processing_progress").notNull().default(0),
  errorMessage: text("error_message"),
  
  // Generated file URLs
  dxfFileUrl: text("dxf_file_url"),
  pdfFileUrl: text("pdf_file_url"),
  pngFileUrl: text("png_file_url"),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertFloorPlanProjectSchema = createInsertSchema(floorPlanProjects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const updateFloorPlanProjectSchema = insertFloorPlanProjectSchema.partial();

export type FloorPlanProject = typeof floorPlanProjects.$inferSelect;
export type InsertFloorPlanProject = z.infer<typeof insertFloorPlanProjectSchema>;
export type UpdateFloorPlanProject = z.infer<typeof updateFloorPlanProjectSchema>;

// Form validation schemas
export const plotDetailsSchema = z.object({
  plotLength: z.number().min(10).max(200),
  plotWidth: z.number().min(10).max(200),
  plotShape: z.enum(["rectangular", "square", "irregular"]),
  roadAccess: z.enum(["north", "south", "east", "west"]),
  entryDirection: z.string(),
  setbackNorth: z.number().min(0).max(20),
  setbackSouth: z.number().min(0).max(20),
  setbackEast: z.number().min(0).max(20),
  setbackWest: z.number().min(0).max(20),
});

export const houseRequirementsSchema = z.object({
  floors: z.number().min(1).max(3),
  bedrooms: z.number().min(1).max(6),
  bathrooms: z.number().min(1).max(4),
  rooms: z.object({
    kitchen: z.boolean(),
    dining: z.boolean(),
    living: z.boolean(),
    pooja: z.boolean(),
    study: z.boolean(),
    parking: z.boolean(),
    balcony: z.boolean(),
  }),
  specialPreferences: z.string().optional(),
  vastuCompliance: z.boolean(),
});

export type PlotDetails = z.infer<typeof plotDetailsSchema>;
export type HouseRequirements = z.infer<typeof houseRequirementsSchema>;
